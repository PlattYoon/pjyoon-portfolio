/**************************************************************************/
/*              COPYRIGHT Carnegie Mellon University 2025                 */
/* Do not post this file or any derivative on a public site or repository */
/**************************************************************************/
#include <assert.h>
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

#include "lib/xalloc.h"
#include "lib/stack.h"
#include "lib/contracts.h"
#include "lib/c0v_stack.h"
#include "lib/c0vm.h"
#include "lib/c0vm_c0ffi.h"
#include "lib/c0vm_abort.h"

/* call stack frames */
typedef struct frame_info frame;
struct frame_info {
  c0v_stack_t  S;   /* Operand stack of C0 values */
  ubyte       *P;   /* Function body */
  size_t       pc;  /* Program counter */
  c0_value    *V;   /* The local variables */
};

int execute(struct bc0_file *bc0) {
  REQUIRES(bc0 != NULL);

  /* Variables */
  c0v_stack_t S; /* Operand stack of C0 values */
  ubyte *P;      /* Array of bytes that make up the current function */
  size_t pc;     /* Current location within the current byte array P */
  c0_value *V;   /* Local variables (you won't need this till Task 2) */
  (void) V;      // silences compilation errors about V being currently unused

  /* The call stack, a generic stack that should contain pointers to frames */
  /* You won't need this until you implement functions. */
  gstack_t callStack;
  (void) callStack; // silences compilation errors about callStack being currently unused

  while (true) {

#ifdef DEBUG
    /* You can add extra debugging information here */
    fprintf(stderr, "Opcode %x -- Stack size: %zu -- PC: %zu\n",
            P[pc], c0v_stack_size(S), pc);
#endif

    switch (P[pc]) {

    /* Additional stack operation: */

    case POP: {
      pc++;
      c0v_pop(S);
      break;
    }

    case DUP: {
      pc++;
      c0_value v = c0v_pop(S);
      c0v_push(S,v);
      c0v_push(S,v);
      break;
    }

    case SWAP: {
      pc++;
      c0_value v1 = c0v_pop(S);
      c0_value v2 = c0v_pop(S);
      c0v_push(S,v2);
      c0v_push(S,v1);
    }


    /* Returning from a function.
     * This currently has a memory leak! You will need to make a slight
     * change for the initial tasks to avoid leaking memory.  You will
     * need to revise it further when you write INVOKESTATIC. */

    case RETURN: {
      int retval = val2int(c0v_pop(S));
      ASSERT(c0v_stack_empty(S));
// Another way to print only in DEBUG mode
IF_DEBUG(fprintf(stderr, "Returning %d from execute()\n", retval));
      // Free everything before returning from the execute function!
      return retval;
    }


    /* Arithmetic and Logical operations */

    case IADD: {
      pc++;
      c0_value y = c0v_pop(S);
      c0_value x = c0v_pop(S);
      int result = val2int(x) + val2int(y);
      c0v_push(S,int2val(result));
    }


    case ISUB:{
      pc++;
      c0_value y = c0v_pop(S);
      c0_value x = c0v_pop(S);
      int result = val2int(x) - val2int(y);
      c0v_push(S,int2val(result));
    }

    case IMUL:{
      pc++;
      c0_value y = c0v_pop(S);
      c0_value x = c0v_pop(S);
      int result = val2int(x) * val2int(y);
      c0v_push(S,int2val(result));

    }

    case IDIV:{
      pc++;
      c0_value y = c0v_pop(S);
      c0_value x = c0v_pop(S);
      REQUIRES(y!=0)
      int result = val2int(x) / val2int(y);
      c0v_push(S,int2val(result));
    }

    case IREM:{
      pc++;
      c0_value y = c0v_pop(S);
      c0_value x = c0v_pop(S);
      int result = val2int(x) % val2int(y);
      c0v_push(S,int2val(result));

    }

    case IAND:{
      pc++;
      c0_value y = c0v_pop(S);
      c0_value x = c0v_pop(S);
      int result = val2int(x) & val2int(y);
      c0v_push(S,int2val(result));
    }

    case IOR:{
      pc++;
      c0_value y = c0v_pop(S);
      c0_value x = c0v_pop(S);
      int result = (val2int(x) || val2int(y));
      c0v_push(S,int2val(result));
    }

    case IXOR:{
      pc++;
      c0_value y = c0v_pop(S);
      c0_value x = c0v_pop(S);
      int result = val2int(x) ^ val2int(y);
      c0v_push(S,int2val(result));
    }

    case ISHR:{
      pc++;
      c0_value y = c0v_pop(S);
      c0_value x = c0v_pop(S);
      int result = val2int(x) >> val2int(y);
      c0v_push(S,int2val(result));

    }

    case ISHL:{
      pc++;
      c0_value y = c0v_pop(S);
      c0_value x = c0v_pop(S);
      int result = val2int(x) << val2int(y);
      c0v_push(S,int2val(result));
    }


    /* Pushing constants */

    case BIPUSH:{
      pc++;

    }

    case ILDC:

    case ALDC:

    case ACONST_NULL:


    /* Operations on local variables */

    case VLOAD:

    case VSTORE:


    /* Assertions and errors */

    case ATHROW:

    case ASSERT:


    /* Control flow operations */

    case NOP:

    case IF_CMPEQ:

    case IF_CMPNE:

    case IF_ICMPLT:

    case IF_ICMPGE:

    case IF_ICMPGT:

    case IF_ICMPLE:

    case GOTO:


    /* Function call operations: */

    case INVOKESTATIC:

    case INVOKENATIVE:


    /* Memory allocation and access operations: */

    case NEW:

    case IMLOAD:

    case IMSTORE:

    case AMLOAD:

    case AMSTORE:

    case CMLOAD:

    case CMSTORE:

    case AADDF:


    /* Array operations: */

    case NEWARRAY:

    case ARRAYLENGTH:

    case AADDS:


    /* BONUS -- C1 operations */

    case CHECKTAG:

    case HASTAG:

    case ADDTAG:

    case ADDROF_STATIC:

    case ADDROF_NATIVE:

    case INVOKEDYNAMIC:

    default:
      fprintf(stderr, "invalid opcode: 0x%02x\n", P[pc]);
      abort();
    }
  }

  /* cannot get here from infinite loop */
  assert(false);
}
